// Select elements
const todoInput = document.getElementById('todo-input');
const addBtn = document.getElementById('add-btn');
const todoList = document.getElementById('todo-list');
const clearBtn = document.getElementById('clear-btn');

// Load todos from LocalStorage
document.addEventListener('DOMContentLoaded', loadTodos);

// Add todo event listener
addBtn.addEventListener('click', addTodo);
clearBtn.addEventListener('click', clearAllTodos);

// Function to add a new todo
function addTodo() {
    const todoText = todoInput.value.trim();
    
    if (todoText === '') {
        alert('Please enter a task.');
        return;
    }

    const li = document.createElement('li');
    
    // Create span for task text
    const taskSpan = document.createElement('span');
    taskSpan.textContent = todoText;
    taskSpan.classList.add('task-text');

    // Create the Done button
    const doneBtn = document.createElement('button');
    doneBtn.textContent = 'Done';
    doneBtn.classList.add('done-btn');
    doneBtn.addEventListener('click', markAsDone);

    // Create the Delete button
    const deleteBtn = document.createElement('button');
    deleteBtn.textContent = 'Delete';
    deleteBtn.classList.add('delete-btn');
    deleteBtn.addEventListener('click', deleteTodo);

    li.appendChild(taskSpan); // Append the task text
    li.appendChild(doneBtn);
    li.appendChild(deleteBtn);

    todoList.appendChild(li);
    saveTodoToLocal(todoText);

    todoInput.value = ''; // Clear input field
}

// Function to mark a task as done
function markAsDone(e) {
    const li = e.target.parentElement;
    li.classList.toggle('completed');
}

// Function to delete a todo
function deleteTodo(e) {
    const li = e.target.parentElement;
    const todoText = li.querySelector('.task-text').textContent;
    li.remove();
    removeTodoFromLocal(todoText);
}

// Function to clear all todos
function clearAllTodos() {
    if (confirm('Are you sure you want to clear all tasks?')) {
        localStorage.clear();
        todoList.innerHTML = '';
    }
}

// Function to save a todo to LocalStorage
function saveTodoToLocal(todo) {
    let todos = getTodosFromLocal();
    todos.push(todo);
    localStorage.setItem('todos', JSON.stringify(todos));
}

// Function to remove a todo from LocalStorage
function removeTodoFromLocal(todoText) {
    let todos = getTodosFromLocal();
    todos = todos.filter(todo => todo !== todoText);
    localStorage.setItem('todos', JSON.stringify(todos));
}

// Function to get todos from LocalStorage
function getTodosFromLocal() {
    let todos;
    if (localStorage.getItem('todos') === null) {
        todos = [];
    } else {
        todos = JSON.parse(localStorage.getItem('todos'));
    }
    return todos;
}

// Function to load todos from LocalStorage when the page loads
function loadTodos() {
    const todos = getTodosFromLocal();
    todos.forEach(todo => {
        const li = document.createElement('li');

        // Create span for task text
        const taskSpan = document.createElement('span');
        taskSpan.textContent = todo;
        taskSpan.classList.add('task-text');

        // Create the Done button
        const doneBtn = document.createElement('button');
        doneBtn.textContent = 'Done';
        doneBtn.classList.add('done-btn');
        doneBtn.addEventListener('click', markAsDone);

        // Create the Delete button
        const deleteBtn = document.createElement('button');
        deleteBtn.textContent = 'Delete';
        deleteBtn.classList.add('delete-btn');
        deleteBtn.addEventListener('click', deleteTodo);

        li.appendChild(taskSpan); // Append the task text
        li.appendChild(doneBtn);
        li.appendChild(deleteBtn);

        todoList.appendChild(li);
    });
}
