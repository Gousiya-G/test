// Handle "Add Event" button click
document.getElementById("addEventBtn").addEventListener("click", () => {
    document.getElementById("addEventSection").classList.remove("hidden");
    document.getElementById("calendarSection").classList.add("hidden");
    document.getElementById("upcomingEventsSection").classList.add("hidden");
    scrollToSection("addEventSection");
});

// Handle "View Upcoming Events" button click
document.getElementById("viewEventsBtn").addEventListener("click", () => {
    displayUpcomingEvents();
    document.getElementById("addEventSection").classList.add("hidden");
    document.getElementById("calendarSection").classList.add("hidden");
    document.getElementById("upcomingEventsSection").classList.remove("hidden");
    scrollToSection("upcomingEventsSection");
});

// Handle event form submission
document.getElementById("eventForm").addEventListener("submit", addEvent);

function addEvent(e) {
    e.preventDefault();

    const title = document.getElementById("title").value;
    const date = document.getElementById("date").value;
    const time = document.getElementById("time").value;
    const description = document.getElementById("description").value;

    const event = { title, date, time, description };

    // Retrieve events from localStorage or initialize an empty array
    let events = localStorage.getItem("events");
    events = events ? JSON.parse(events) : [];
    events.push(event);

    // Save updated events back to localStorage
    localStorage.setItem("events", JSON.stringify(events));

    alert("Event added successfully!");
    clearForm();
    document.getElementById("addEventSection").classList.add("hidden");
    document.getElementById("calendarSection").classList.remove("hidden");
    scrollToSection("calendarSection");
}

function displayUpcomingEvents() {
    const eventsList = document.getElementById("eventsList");
    eventsList.innerHTML = "";

    let events = localStorage.getItem("events");
    events = events ? JSON.parse(events) : [];

    if (events.length === 0) {
        eventsList.innerHTML = "<li>No upcoming events</li>";
        return;
    }

    events.forEach(event => {
        const li = document.createElement("li");
        li.textContent = `${event.title} on ${event.date} at ${event.time}`;
        eventsList.appendChild(li);
    });
}

function clearForm() {
    document.getElementById("title").value = "";
    document.getElementById("date").value = "";
    document.getElementById("time").value = "";
    document.getElementById("description").value = "";
}

// Initialize FullCalendar
document.addEventListener("DOMContentLoaded", function() {
    var calendarEl = document.getElementById('calendar');
    var calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        events: fetchEvents() // Load events from localStorage into the calendar
    });
    calendar.render();
});

function fetchEvents() {
    let events = localStorage.getItem("events");
    events = events ? JSON.parse(events) : [];

    return events.map(event => ({
        title: event.title,
        start: event.date + 'T' + event.time
    }));
}

function scrollToSection(sectionId) {
    const section = document.getElementById(sectionId);
    if (section) {
        section.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
}
