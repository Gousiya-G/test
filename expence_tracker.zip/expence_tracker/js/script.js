document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('expense-form');
    const expenseList = document.getElementById('expense-list');
    const totalAmountElem = document.getElementById('total-amount');
    let totalAmount = 0;
    
    form.addEventListener('submit', (event) => {
        event.preventDefault();
        
        const name = document.getElementById('expense-name').value;
        const amount = parseFloat(document.getElementById('expense-amount').value);
        
        if (name && !isNaN(amount)) {
            addExpense(name, amount);
            form.reset();
        }
    });
    
    function addExpense(name, amount) {
        const expenseItem = document.createElement('div');
        expenseItem.classList.add('expense-item');
        
        expenseItem.innerHTML = `
            <span>${name} - ₹${amount.toFixed(2)}</span>
            <button onclick="removeExpense(this, ${amount})">Delete</button>
        `;
        
        expenseList.appendChild(expenseItem);
        updateTotalAmount(amount);
    }
    
    function updateTotalAmount(amount) {
        totalAmount += amount;
        totalAmountElem.textContent = `₹${totalAmount.toFixed(2)}`;
    }
    
    window.removeExpense = function(button, amount) {
        const expenseItem = button.parentElement;
        expenseItem.remove();
        updateTotalAmount(-amount);
    }
});
